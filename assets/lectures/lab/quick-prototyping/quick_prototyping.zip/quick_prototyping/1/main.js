$(function() {
  // Your interactions go here
});
